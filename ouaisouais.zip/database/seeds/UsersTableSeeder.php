<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([  
            'name' => 'Ben',  
            'email' => 'ben@bonjour.com',  
            'password' => Hash::make('ben@bonjour.com') ,  
            'id_role' => '1',  
        ]);
        DB::table('users')->insert([  
            'name' => 'Harry',  
            'email' => 'Harry@Potter.com',  
            'password' => Hash::make('Harry@Potter.com'),  
            'id_role' => '2',  

        ]);
        DB::table('users')->insert([  
            'name' => 'Testo',  
            'email' => 'Testo@gmail.com',  
            'password' => Hash::make('Testo@gmail.com'),  
            'id_role' => '3',  
        ]);
    }
}
