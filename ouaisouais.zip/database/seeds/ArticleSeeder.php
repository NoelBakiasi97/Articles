<?php

use Illuminate\Database\Seeder;

class ArticleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('articles')->insert([  
            'titre' => 'premier aticle',  
            'description' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Distinctio iure ab deserunt, et architecto placeat sed quidem sapiente ea, aperiam corrupti maiores quisquam cumque minus itaque voluptas natus voluptatibus ex?',  
            'img' => 'Aangjpg.jpg',  
            'contenu' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aspernatur, quibusdam unde commodi autem eius iste, laborum, temporibus vero veritatis ducimus reprehenderit! Sequi consequatur, aperiam fuga amet qui dolore? Harum, molestias?
            Ullam minus corporis itaque neque temporibus, sit repellat nihil consequatur debitis ad vitae beatae accusantium voluptatem aspernatur maiores ipsam iste. Sapiente consequatur sit eum nesciunt excepturi reiciendis, laboriosam accusantium earum!
            Debitis veniam dolore, quod inventore minus sint! Provident temporibus, nam atque excepturi expedita consequuntur, doloremque a neque quam architecto ad velit molestias quisquam. Odio optio molestias adipisci similique quia eligendi.
            Accusantium, sed odio aut sunt voluptatibus labore vel sapiente eveniet? Harum numquam molestias iste obcaecati sint nobis facere, fugiat aliquam officiis mollitia illum fugit necessitatibus. Mollitia voluptates esse officia quam!',  
            'id_user' => '3',  
        ]);
            DB::table('articles')->insert([  
                'titre' => 'un deuxieme pour la route',  
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eum vitae cupiditate aut laudantium in voluptatem blanditiis odit neque? Facere rerum fuga eveniet tempore error at.',  
                'img' => 'AvatarEau.png',  
                'contenu' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aspernatur, quibusdam unde commodi autem eius iste, laborum, temporibus vero veritatis ducimus reprehenderit! Sequi consequatur, aperiam fuga amet qui dolore? Harum, molestias?
                Ullam minus corporis itaque neque temporibus, sit repellat nihil consequatur debitis ad vitae beatae accusantium voluptatem aspernatur maiores ipsam iste. Sapiente consequatur sit eum nesciunt excepturi reiciendis, laboriosam accusantium earum!
                Debitis veniam dolore, quod inventore minus sint! Provident temporibus, nam atque excepturi expedita consequuntur, doloremque a neque quam architecto ad velit molestias quisquam. Odio optio molestias adipisci similique quia eligendi.
                Accusantium, sed odio aut sunt voluptatibus labore vel sapiente eveniet? Harum numquam molestias iste obcaecati sint nobis facere, fugiat aliquam officiis mollitia illum fugit necessitatibus. Mollitia voluptates esse officia quam!',  
                'id_user' => '2',  
            ]);
            DB::table('articles')->insert([  
                'titre' => 'uouais ouiasouais',  
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eum vitae cupiditate aut laudantium in voluptatem blanditiis odit neque? Facere rerum fuga eveniet tempore error at.',  
                'img' => 'AvatarEau.png',  
                'contenu' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aspernatur, quibusdam unde commodi autem eius iste, laborum, temporibus vero veritatis ducimus reprehenderit! Sequi consequatur, aperiam fuga amet qui dolore? Harum, molestias?
                Ullam minus corporis itaque neque temporibus, sit repellat nihil consequatur debitis ad vitae beatae accusantium voluptatem aspernatur maiores ipsam iste. Sapiente consequatur sit eum nesciunt excepturi reiciendis, laboriosam accusantium earum!
                Debitis veniam dolore, quod inventore minus sint! Provident temporibus, nam atque excepturi expedita consequuntur, doloremque a neque quam architecto ad velit molestias quisquam. Odio optio molestias adipisci similique quia eligendi.
                Accusantium, sed odio aut sunt voluptatibus labore vel sapiente eveniet? Harum numquam molestias iste obcaecati sint nobis facere, fugiat aliquam officiis mollitia illum fugit necessitatibus. Mollitia voluptates esse officia quam!',  
                'id_user' => '2',  
            ]);
        DB::table('articles')->insert([  
            'titre' => 'yes sir ',  
            'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem itaque accusamus, placeat nulla unde assumenda!
            ',  
            'img' => 'montagne.jpg',  
            'contenu' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aspernatur, quibusdam unde commodi autem eius iste, laborum, temporibus vero veritatis ducimus reprehenderit! Sequi consequatur, aperiam fuga amet qui dolore? Harum, molestias?
            Ullam minus corporis itaque neque temporibus, sit repellat nihil consequatur debitis ad vitae beatae accusantium voluptatem aspernatur maiores ipsam iste. Sapiente consequatur sit eum nesciunt excepturi reiciendis, laboriosam accusantium earum!
            Debitis veniam dolore, quod inventore minus sint! Provident temporibus, nam atque excepturi expedita consequuntur, doloremque a neque quam architecto ad velit molestias quisquam. Odio optio molestias adipisci similique quia eligendi.
            Accusantium, sed odio aut sunt voluptatibus labore vel sapiente eveniet? Harum numquam molestias iste obcaecati sint nobis facere, fugiat aliquam officiis mollitia illum fugit necessitatibus. Mollitia voluptates esse officia quam!',  
            'id_user' => '3',  
        ]);
        DB::table('articles')->insert([  
            'titre' => 'hvedcsze sir ',  
            'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem itaque accusamus, placeat nulla unde assumenda!
            ',  
            'img' => 'montagne.jpg',  
            'contenu' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aspernatur, quibusdam unde commodi autem eius iste, laborum, temporibus vero veritatis ducimus reprehenderit! Sequi consequatur, aperiam fuga amet qui dolore? Harum, molestias?
            Ullam minus corporis itaque neque temporibus, sit repellat nihil consequatur debitis ad vitae beatae accusantium voluptatem aspernatur maiores ipsam iste. Sapiente consequatur sit eum nesciunt excepturi reiciendis, laboriosam accusantium earum!
            Debitis veniam dolore, quod inventore minus sint! Provident temporibus, nam atque excepturi expedita consequuntur, doloremque a neque quam architecto ad velit molestias quisquam. Odio optio molestias adipisci similique quia eligendi.
            Accusantium, sed odio aut sunt voluptatibus labore vel sapiente eveniet? Harum numquam molestias iste obcaecati sint nobis facere, fugiat aliquam officiis mollitia illum fugit necessitatibus. Mollitia voluptates esse officia quam!',  
            'id_user' => '3',  
        ]);
        DB::table('articles')->insert([  
            'titre' => 'Last one',  
            'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem itaque accusamus, placeat nulla unde assumenda!
            ',  
            'img' => 'montagne.jpg',  
            'contenu' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aspernatur, quibusdam unde commodi autem eius iste, laborum, temporibus vero veritatis ducimus reprehenderit! Sequi consequatur, aperiam fuga amet qui dolore? Harum, molestias?
            Ullam minus corporis itaque neque temporibus, sit repellat nihil consequatur debitis ad vitae beatae accusantium voluptatem aspernatur maiores ipsam iste. Sapiente consequatur sit eum nesciunt excepturi reiciendis, laboriosam accusantium earum!
            Debitis veniam dolore, quod inventore minus sint! Provident temporibus, nam atque excepturi expedita consequuntur, doloremque a neque quam architecto ad velit molestias quisquam. Odio optio molestias adipisci similique quia eligendi.
            Accusantium, sed odio aut sunt voluptatibus labore vel sapiente eveniet? Harum numquam molestias iste obcaecati sint nobis facere, fugiat aliquam officiis mollitia illum fugit necessitatibus. Mollitia voluptates esse officia quam!',  
            'id_user' => '3',  
        ]);
    }
}
