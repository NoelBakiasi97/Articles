<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\Role;


class ProfilController extends Controller
{
    public function index()   
    {
        $users = User::all();
        $roles = Role::all();
        if (Auth::check()) {
            
            return view('user/myprofil',compact('users','roles'));
        }else {
            return redirect()->back();
        }
    }
     public function edit($id)
    {
        $user = User::find($id);
        $roles = Role::all();
        return view('user/editMyprofil',compact('user','roles'));
    }
     public function update(Request $request, $id)
    {   
        if (Auth::id()== $id) {
            $validatedData = $request->validate([
                'name' => 'required',
                'email' => 'required|email|unique:users,email,'.$id,
            ]);
                $users = User::find($id);
    
                $users->name = $request->input('name');
                $users->email = $request->input('email');
               
                $users->save();
                return redirect()->route('myProfil');
        } else {
            return redirect()->back();        
        }
    }
    public function destroy($id)
    {
        $user = User::find($id);
        $user->delete();
        return redirect()->route('welcome');
    }   
}
