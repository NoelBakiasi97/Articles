<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Role;

class RoleController extends Controller
{
    public function index(){
        $roles = Role::all();
        return view('roles/roles',compact('roles'));
    }
    public function create()
    {
        return view('roles/addRole');
    }
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'role'=>'required|unique:roles',
        ]);
        $roles = new Role();
        $roles->role =  $request->input('role');
        $roles->save();

        return redirect()->route('roles');
    }
    public function edit($id)
    {
        $role = Role::find($id);
        return view('roles/editRole',compact('role'));
    }
    public function update(Request $request, $id)
    { 
        $validatedData = $request->validate([
            'role'=>'required|unique:roles,role,'.$id,
        ]);
        $roles = Role::find($id);
        $roles->role =  $request->input('role');
        $roles->save();

        return redirect()->route('roles');
    }

    public function destroy($id)
    {
        $roles = Role::find($id);
        $roles->delete();
        return redirect()->route('roles');
    }
}
