<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Redacteurrequest extends Model
{
    protected $table = 'redacteurrequests';
}
