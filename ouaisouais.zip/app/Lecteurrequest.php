<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lecteurrequest extends Model
{
    protected $table = 'lecteurrequests';

}
