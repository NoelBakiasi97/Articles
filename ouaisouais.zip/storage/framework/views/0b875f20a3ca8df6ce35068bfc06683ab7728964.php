<div class="container">
    <div class="text-center">
        <h1>Mon abonnement de lecteur</h1>

        <?php if(App\Redacteurrequest::where('id_user',Auth::id())->exists() ): ?>
            <h3>vous avez deja fait votre demande</h3>
        <?php else: ?>
            <a class="btn btn-primary" href="<?php echo e(route('saveRedacteurRequests')); ?>">Devenir redacteur</a>
        <?php endif; ?>
    </div>


</div>
<?php /**PATH /mnt/c/wamp64/www/molengeekwamp/exo_article/resources/views/lecteur.blade.php ENDPATH**/ ?>