<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__errorArgs = ['msg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	<div class="alert alert-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <?php if(Auth::check()): ?>
        
        <?php echo $__env->make('news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        
        <?php if(Auth::user()->id_role==2): ?>
            <?php echo $__env->make('utilisateur', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(Auth::user()->id_role==3): ?>
            <?php echo $__env->make('lecteur', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(Auth::user()->id_role==4): ?>
            <?php echo $__env->make('redacteur', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    





    <?php else: ?>
        <div class="container">
            <h1>Inscrivez-vous ou connectez-vous pour beneficier de nos articles</h1>
            <div class="text-center ">
                <ul class="" style="list-style:none">

                    <li>
                        <a class="btn btn-secondary my-3" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                    <?php if(Route::has('register')): ?>
                        <li >
                            <a class="btn btn-secondary" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

    <?php endif; ?>
    


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/c/wamp64/www/molengeekwamp/exo_article/resources/views/welcome.blade.php ENDPATH**/ ?>