
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="text-center">
        <h1><?php echo e($article->titre); ?></h1>
    </div>
    <div class="text-center">
    <img src="<?php echo e(asset('storage/'.$article->img)); ?>" alt="">
    </div>

    <div class="container"> 
        <p><?php echo e($article->contenu); ?></p>

    </div>
    <div class="text-center">
        <div class="text-center"> <a class="btn btn-primary" href="<?php echo e(route('articles')); ?>">Voir les autres articles</a> </div>

    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/c/wamp64/www/molengeekwamp/exo_article/resources/views/articles/article.blade.php ENDPATH**/ ?>