<div class="mx-5">
    <div class="text-center">
        <h1>Voici les 5 derniers articles</h1>
    </div>

    <div class="row  d-flex justify-content-around">
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
        <div class="col-2 px-0 ">
            <div class="card "  >
                <img src="<?php echo e(asset('storage/'.$article->img)); ?>" class="card-img-top " alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($article->titre); ?></h5>
                    <p class="card-text"><?php echo e($article->description); ?></p>
                    <a href="<?php echo e(route('article',$article->id)); ?> " class="btn btn-primary">voir article</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="text-center"> <a class="btn btn-primary" href="<?php echo e(route('articles')); ?>">Voir les autres articles</a> </div>
</div>
<?php /**PATH /mnt/c/wamp64/www/molengeekwamp/exo_article/resources/views/news.blade.php ENDPATH**/ ?>