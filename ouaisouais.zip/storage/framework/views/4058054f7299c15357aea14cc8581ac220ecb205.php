<div class="container">
    <div class="text-center">
        <h1>Mon abonnement de redacteur</h1>
        <a href="<?php echo e(route('articles')); ?>">Voir les articles</a>
    </div>


</div>
<?php /**PATH /mnt/c/wamp64/www/molengeekwamp/exo_article/resources/views/redacteur.blade.php ENDPATH**/ ?>