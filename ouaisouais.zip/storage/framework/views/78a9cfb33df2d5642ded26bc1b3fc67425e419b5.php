
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="mb-5 container">
        <div class="text-center">
            
            <h1>Articles </h1>
        </div>
        <div class="container text-center">
            <a class="btn btn-success my-2" href="<?php echo e(route('addArticle')); ?>">ajouter une article </a>
        </div>
                <table class="table table-striped table-secondary">
                    <thead class="bg-dark text-warning">
                        <tr>
                            <th scope="col" class="text-center">Id</th>
                            <th scope="col" class="text-center">titre</th>
                            <th scope="col" class="text-center">description</th>
                            <th scope="col" class="text-center">image</th>
                            <th scope="col" class="text-center">auteur</th>
                            <th scope="col" class="text-center">action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row" class="text-center"><?php echo e($article->id); ?></th>
                            <td class="text-center"><?php echo e($article->titre); ?></td> 
                            <td class="text-center"><?php echo e($article->description); ?></td> 
                            <td class="text-center"><img class="w-25" src="<?php echo e(asset('storage/'.$article->img)); ?>" alt=""></td> 
                            <td class="text-center">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($article->id_user == $user->id): ?> 
                                        <?php echo e($user->name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td> 
                            <td class="text-center">
                                <?php if(Auth::user()->id_role==1 ||Auth::id()==$article->id_user ): ?>
                                    
                                    <a class="btn btn-warning" href="<?php echo e(route('editArticle',$article->id)); ?>">edit</a>
                                    <a class="btn btn-danger" href="<?php echo e(route('deleteArticle',$article->id)); ?>">delete</a>
                                <?php endif; ?>

                                <a class="btn btn-success" href="<?php echo e(route('article',$article->id)); ?>">voir article</a>
                            </td> 
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
    
    
    
    
    


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/c/wamp64/www/molengeekwamp/exo_article/resources/views/articles/articles.blade.php ENDPATH**/ ?>