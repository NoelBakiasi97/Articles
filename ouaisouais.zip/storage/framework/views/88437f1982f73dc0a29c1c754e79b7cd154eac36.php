

<?php $__env->startSection('content'); ?>
        

        <div class="mb-5 container">
            <div class="text-center">

                <h1>Users </h1>
            </div>
            <table class="table table-striped table-secondary">
                <thead class="bg-dark text-warning">
                    <tr>
                        <th scope="col" class="text-center">Id</th>
                        <th scope="col" class="text-center">Nom</th>
                        <th scope="col" class="text-center">Email</th>
                        <th scope="col" class="text-center">role</th>
                        <th scope="col" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row" class="text-center"><?php echo e($user->id); ?></th>
                        <td class="text-center"><?php echo e($user->name); ?></td>
                        <td class="text-center"><?php echo e($user->email); ?></td>
                        <td class="text-center">
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->id_role == $role->id): ?>
                                    <?php echo e($role->role); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        
                        <td class="d-flex justify-content-around ">  
                            <?php if($user->id_role!=1): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('editUser',$user->id)); ?>">edit</a>   
                                <a class="btn btn-danger" href="<?php echo e(route('deleteUser',$user->id)); ?>">delete</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/c/wamp64/www/molengeekwamp/exo_article/resources/views/user/user.blade.php ENDPATH**/ ?>