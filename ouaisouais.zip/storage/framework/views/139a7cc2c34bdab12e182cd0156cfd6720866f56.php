
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="text-center">

        <h1 class="text-success">Votre demande a bien été enregistrée</h1>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/c/wamp64/www/molengeekwamp/exo_article/resources/views/demande.blade.php ENDPATH**/ ?>