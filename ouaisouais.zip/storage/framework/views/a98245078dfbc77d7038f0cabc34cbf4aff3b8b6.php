<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="<?php echo e(route('welcome')); ?>">Home</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      
      <ul class="navbar-nav ml-auto">
      <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
            </li>
            <?php if(Route::has('register')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                </li>
            <?php endif; ?>
        <?php else: ?>
            <li class="nav-item dropdown">
                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                  <div class="dropDiv">
                    <a class="dropdown-item colorDrop " href="<?php echo e(route('myProfil')); ?>">
                       My profil
                    </a>
                </div>
                <?php if(Auth::user()->id_role==1 ): ?>
                    <div class="dropDiv">
                        <a class="dropdown-item colorDrop " href="<?php echo e(route('users')); ?>">
                        Users
                        </a>
                    </div>
                    <div class="dropDiv">
                        <a class="dropdown-item colorDrop " href="<?php echo e(route('lecteurRequest')); ?>">
                          lecteurRequest
                        </a>
                    </div>
                    <div class="dropDiv">
                        <a class="dropdown-item colorDrop " href="<?php echo e(route('redacteurRequests')); ?>">
                          redacteurRequests
                        </a>
                    </div>
                <?php endif; ?>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
        <?php endif; ?>
    </ul>
    </div>
  </nav><?php /**PATH /mnt/c/wamp64/www/molengeekwamp/exo_article/resources/views/components/nav.blade.php ENDPATH**/ ?>