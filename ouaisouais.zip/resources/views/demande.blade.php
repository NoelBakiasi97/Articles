@extends('layouts.master')
@section('content')
@include('components.nav')
<div class="container">
    <div class="text-center">

        <h1 class="text-success">Votre demande a bien été enregistrée</h1>
    </div>
</div>
    
@endsection