@extends('layouts.master')
@section('content')
@include('components.nav')
@error('msg')
	<div class="alert alert-danger">{{$message}}</div>
@enderror

    @if (Auth::check())
        
        @include('news') 
        
        @if (Auth::user()->id_role==2)
            @include('utilisateur')
        @endif
        @if (Auth::user()->id_role==3)
            @include('lecteur')
        @endif
        @if (Auth::user()->id_role==4)
            @include('redacteur')
        @endif
    





    @else
        <div class="container">
            <h1>Inscrivez-vous ou connectez-vous pour beneficier de nos articles</h1>
            <div class="text-center ">
                <ul class="" style="list-style:none">

                    <li>
                        <a class="btn btn-secondary my-3" href="{{ route('login') }}">{{ __('Login') }}</a>
                    </li>
                    @if (Route::has('register'))
                        <li >
                            <a class="btn btn-secondary" href="{{ route('register') }}">{{ __('Register') }}</a>
                        </li>
                    @endif
                </ul>
            </div>
        </div>

    @endif
    


    
@endsection