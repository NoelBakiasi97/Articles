<div class="container">
    <div class="text-center">
        <h1>Mon abonnement d'utilisateur</h1>
       
        @if (App\Lecteurrequest::where('id_user',Auth::id())->exists() )
            <h3>vous avez deja fait votre demande</h3>
        @else
            <a class="btn btn-primary" href="{{route('saveLecteurRequest')}}">Devenir lecteur</a>
        @endif
    
    
    </div>


</div>
