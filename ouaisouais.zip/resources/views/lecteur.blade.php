<div class="container">
    <div class="text-center">
        <h1>Mon abonnement de lecteur</h1>

        @if (App\Redacteurrequest::where('id_user',Auth::id())->exists() )
            <h3>vous avez deja fait votre demande</h3>
        @else
            <a class="btn btn-primary" href="{{route('saveRedacteurRequests')}}">Devenir redacteur</a>
        @endif
    </div>


</div>
