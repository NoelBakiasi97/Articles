<div class="container">
    <div class="text-center">
        <h1>Mon abonnement de redacteur</h1>
        <a href="{{route('articles')}}">Voir les articles</a>
    </div>


</div>
