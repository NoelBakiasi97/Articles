@extends('layouts.master')
@section('content')
    @include('components.nav')
    <div class="text-center">
        <h1>{{$article->titre}}</h1>
    </div>
    <div class="text-center">
    <img src="{{asset('storage/'.$article->img)}}" alt="">
    </div>

    <div class="container"> 
        <p>{{$article->contenu}}</p>

    </div>
    <div class="text-center">
        <div class="text-center"> <a class="btn btn-primary" href="{{route('articles')}}">Voir les autres articles</a> </div>

    </div>
    
@endsection