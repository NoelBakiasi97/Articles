@extends('layouts.master')
@section('content')
    @include('components.nav')

    <div class="mb-5 container">
        <div class="text-center">
            
            <h1>Articles </h1>
        </div>
        <div class="container text-center">
            <a class="btn btn-success my-2" href="{{route('addArticle')}}">ajouter une article </a>
        </div>
                <table class="table table-striped table-secondary">
                    <thead class="bg-dark text-warning">
                        <tr>
                            <th scope="col" class="text-center">Id</th>
                            <th scope="col" class="text-center">titre</th>
                            <th scope="col" class="text-center">description</th>
                            <th scope="col" class="text-center">image</th>
                            <th scope="col" class="text-center">auteur</th>
                            <th scope="col" class="text-center">action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($articles as $article)
                        <tr>
                            <th scope="row" class="text-center">{{$article->id}}</th>
                            <td class="text-center">{{$article->titre}}</td> 
                            <td class="text-center">{{$article->description}}</td> 
                            <td class="text-center"><img class="w-25" src="{{asset('storage/'.$article->img)}}" alt=""></td> 
                            <td class="text-center">
                                @foreach ($users as $user)
                                    @if ($article->id_user == $user->id) 
                                        {{$user->name}}
                                    @endif
                                @endforeach
                            </td> 
                            <td class="text-center">
                                @if (Auth::user()->id_role==1 ||Auth::id()==$article->id_user )
                                    
                                    <a class="btn btn-warning" href="{{route('editArticle',$article->id)}}">edit</a>
                                    <a class="btn btn-danger" href="{{route('deleteArticle',$article->id)}}">delete</a>
                                @endif

                                <a class="btn btn-success" href="{{route('article',$article->id)}}">voir article</a>
                            </td> 
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
    
    
    
    
    


    
@endsection